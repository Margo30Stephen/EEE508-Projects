imageUsed = imread("airplane_grayscale.png");

[h,w] = size(imageUsed);
img2double = double(imageUsed);

figure(1);
imshow(imageUsed);
title("Original Image");


imageUsed = double(imageUsed);

robertMatrix = zeros(size(imageUsed));
  
% Robert Operator Mask
Mx = [1 0; 0 -1];
My = [0 1; -1 0];

for i=2:h -1
    for j=2:w-1
  
        % Gradient approximations
        Gx = sum(sum(Mx.*imageUsed(i:i+1, j:j+1)));
        Gy = sum(sum(My.*imageUsed(i:i+1, j:j+1)));
        robertMatrix(i,j)= sqrt(Gx^2+Gy^2);
    end
end

%--------- Type 1 --------------%
type1 = uint8(robertMatrix);
figure(2)
imshow(type1);
title("Type 1");


%--------- Type 2 ---------------%
sample1= robertMatrix;
for i=1:h-1
    for j=1:w-1
        if sample1(i,j) < 25.0
            sample1(i,j) = img2double(i,j);
        end
    end
end
type2 = uint8(sample1);
figure(3);
imshow(type2);
title("Type 2");


%---------- Type 3 -----------------%
sample2 = robertMatrix;
for i=1:h-1
    for j=1:w-1
        if sample2(i,j) >= 25
            sample2(i,j) = 255;
        else
            sample2(i,j) = img2double(i,j);
        end
    end
end

type3 = uint8(sample2);
figure(4);
imshow(type3);
title("Type 3");

%------------- Type 4---------------%
sample3 = robertMatrix;
for i=1:h-1
    for j=1:w-1
        if sample3(i,j) < 25
            sample3(i,j) = 0;
        end
    end
end
type4 = uint8(sample3);
figure(5);
imshow(type4);
title("Type 4");

%------------ Type 5 ---------------%
sample4 = robertMatrix;
for i=1:h-1
    for j=1:w-1
        if sample4(i,j)>= 25
            sample4(i,j) = 255;
        else
            sample4(i,j) = 0;
        end
    end
end
type5 = uint8(sample4);
figure(6);
imshow(type5);
title("Type 5");
