close all;
clear;
clc;

%%  Reading of the given image
img = imread('lena512noisy.bmp');
img_FFT = fft2(img);

[LoD, HiD, LoR, HiR] = wfilters('db2'); 
% expansion for avoiding edge disortion

%% Decompose noisy image into subbands using
%   16-band dyadic (LoD - LPF, HiD - HPF)

[cA, cH, cV, cD] = dwt2(img,LoD,HiD,'mode','sym');  % cA=LowLow, cH=LowHigh, cV=HighLow, cD=HighHigh
figure;
subplot(2,2,1);imagesc(cA);
title("Level 1 Dec LowLow")
subplot(2,2,3);imagesc(cH);
title("Level 1 Dec LowHigh")
subplot(2,2,2);imagesc(cV);
title("Level 1 Dec HighLow")
subplot(2,2,4);imagesc(cD);
title("Level 1 Dec HighHigh")
colormap(gray)

[d1,d2,d3,d4] = dwt2(cA,LoD,HiD,'mode','sym');
[d5,d6,d7,d8] = dwt2(cH,LoD,HiD,'mode','sym');
[d9,d10,d11,d12] = dwt2(cV,LoD,HiD,'mode','sym');
[d13,d14,d15,d16] = dwt2(cD,LoD,HiD,'mode','sym');


%   22-band modified pyramid
[m1,m2,m3,m4] = dwt2(cA,LoD,HiD,'mode','sym');
[m5,m6,m7,m8] = dwt2(cH,LoD,HiD,'mode','sym');
[m9,m10,m11,m12] = dwt2(cV,LoD,HiD,'mode','sym');
[m13,m14,m15,m16] = dwt2(cD,LoD,HiD,'mode','sym');
%   adding two additional decomposition to the lowest subband.
[m1_1,m1_2,m1_3,m1_4] = dwt2(m1,LoD,HiD,'mode','sym');
[m1_1_1, m1_1_2, m1_1_3, m1_1_4] = dwt2(m1_1,LoD,HiD,'mode','sym');
%   Useing 'dwt' filter with eliminate edge effects

%%  Removal of high-frequency noise signal from frequency domain subbands
%% A per instructions
%   Dyadic case
%       highest-frequency = 0 (size = 131*131)
%       3 highest-frequency = 0 (sizes = 131*131)
%       6 highest-frequency = 0 (sizes = 131*131)
%   Modified pyramid case
%       3 highest-frequency = 0 (sizes = 131*131)
%       10 highest-frequency = 0    (sizes = 131*131)
%       15 highest-frequency = 0    (sizes = 131*131)
zero_array = zeros(length(d16)); % will apply this zero_array back




%%  Form reconstructed image in each case by Inverse dwt
%   Dyadic case
%       highest-frequency = 0
%   d16
cAReconstruct = idwt2(d1,d2,d3,d4,LoR,HiR);
cHReconstruct = idwt2(d5,d6,d7,d8,LoR,HiR);
cVReconstruct = idwt2(d9,d10,d11,d12,LoR,HiR);
cDReconstruct = idwt2(d13,d14,d15,zero_array,LoR,HiR);
img_D1 = idwt2(cAReconstruct,cHReconstruct,cVReconstruct,cDReconstruct,LoR,HiR);
img_FFT_D1 = fft2(img_D1);
% double to uint8 for output format (0~255); or double (0~1)->img./256 
img_D1 = uint8(img_D1);

%       3 highest-frequency = 0
%   d14, d15, d16
cAReconstruct = idwt2(d1,d2,d3,d4,LoR,HiR);
cHReconstruct = idwt2(d5,d6,d7,d8,LoR,HiR);
cVReconstruct = idwt2(d9,d10,d11,d12,LoR,HiR);
cDReconstruct = idwt2(d13,zero_array,zero_array,zero_array,LoR,HiR);
img_D2 = idwt2(cAReconstruct,cHReconstruct,cVReconstruct,cDReconstruct,LoR,HiR);
img_FFT_D2 = fft2(img_D2);
% double to uint8 for output format (0~255); or double (0~1)->img./256 
img_D2 = uint8(img_D2);

%       6 highest-frequency = 0
%   d8, d12, d13, d14, d15, d16
cAReconstruct = idwt2(d1,d2,d3,d4,LoR,HiR);
cHReconstruct = idwt2(d5,d6,d7,zero_array,LoR,HiR);
cVReconstruct = idwt2(d9,d10,d11,zero_array,LoR,HiR);
cDReconstruct = idwt2(zero_array,zero_array,zero_array,zero_array,LoR,HiR);
img_D3 = idwt2(cAReconstruct,cHReconstruct,cVReconstruct,cDReconstruct,LoR,HiR);
img_FFT_D3 = fft2(img_D3);
% double to uint8 for output format (0~255); or double (0~1)->img./256 
img_D3 = uint8(img_D3);

%   Modified pyramid case
%       3 highest-frequency = 0
%   m14, m15, m16
m1_1 = idwt2(m1_1_1,m1_1_2,m1_1_3,m1_1_4,LoR,HiR);
m1 = idwt2(m1_1,m1_2,m1_3,m1_4,LoR,HiR);
cAReconstruct = idwt2(m1,m2,m3,m4,LoR,HiR);
cHReconstruct = idwt2(m5,m6,m7,m8,LoR,HiR);
cVReconstruct = idwt2(m9,m10,m11,m12,LoR,HiR);
cDReconstruct = idwt2(m13,zero_array,zero_array,zero_array,LoR,HiR);
img_MP1 = idwt2(cAReconstruct,cHReconstruct,cVReconstruct,cDReconstruct,LoR,HiR);
img_FFT_MP1 = fft2(img_MP1);
% double to uint8 for output format (0~255); or double (0~1)->img./256 
img_MP1 = uint8(img_MP1);

%       10 highest-frequency = 0
%   m6, m7, m8, m10, m11, m12, m13, m14, m15, m16
m1_1 = idwt2(m1_1_1,m1_1_2,m1_1_3,m1_1_4,LoR,HiR);
m1 = idwt2(m1_1,m1_2,m1_3,m1_4,LoR,HiR);
cAReconstruct = idwt2(m1,m2,m3,m4,LoR,HiR);
cHReconstruct = idwt2(m5,zero_array,zero_array,zero_array,LoR,HiR);
cVReconstruct = idwt2(m9,zero_array,zero_array,zero_array,LoR,HiR);
cDReconstruct = idwt2(zero_array,zero_array,zero_array,zero_array,LoR,HiR);
img_MP2 = idwt2(cAReconstruct,cHReconstruct,cVReconstruct,cDReconstruct,LoR,HiR);
img_FFT_MP2 = fft2(img_MP2);
% double to uint8 for output format (0~255); or double (0~1)->img./256 
img_MP2 = uint8(img_MP2);

%       15 highest-frequency = 0
%   m2:m16
m1_1 = idwt2(m1_1_1,m1_1_2,m1_1_3,m1_1_4,LoR,HiR);
m1 = idwt2(m1_1,m1_2,m1_3,m1_4,LoR,HiR);
cAReconstruct = idwt2(m1,zero_array,zero_array,zero_array,LoR,HiR);
cHReconstruct = idwt2(zero_array,zero_array,zero_array,zero_array,LoR,HiR);
cVReconstruct = idwt2(zero_array,zero_array,zero_array,zero_array,LoR,HiR);
cDReconstruct = idwt2(zero_array,zero_array,zero_array,zero_array,LoR,HiR);
img_MP3 = idwt2(cAReconstruct,cHReconstruct,cVReconstruct,cDReconstruct,LoR,HiR);
img_FFT_MP3 = fft2(img_MP3);
% double to uint8 for output format (0~255); or double (0~1)->img./256 
img_MP3 = uint8(img_MP3);

%%  Figure Plotting
%   Original noisy image plotting
figure;
imagesc(img)
title("Noisy Figure")
colormap(gray)

figure;
plot(10*log10(abs(img_FFT)))
xlim([1 length(img_FFT)])
title("Noisy Figure FFT (Mag)")

%   Dyadic case
%       highest-frequency = 0
figure
imagesc(img_D1)
title("Dyadic, One Highest Frequency = 0")
colormap(gray)

imwrite(img_D1,'img_Dyadic_one_HF.bmp')

figure
plot(10*log10(abs(img_FFT_D1)))
xlim([1 length(img_FFT_D1)])
title("Dyadic, one Highest Frequency FFT (Mag)")

%       3 highest-frequency = 0
figure
imagesc(img_D2)
title("Dyadic, Three Highest Frequency = 0")
colormap(gray)

imwrite(img_D2,'img_Dyadic_three_HF.bmp')

figure
plot(10*log10(abs(img_FFT_D2)))
xlim([1 length(img_FFT_D2)])
title("Dyadic, three HF FFT (Mag)")

%       6 highest-frequency = 0
figure
imagesc(img_D3)
title("Dyadic, Six Highest Frequency = 0")
colormap(gray)

imwrite(img_D3,'img_Dyadic_six_HF.bmp')

figure
plot(10*log10(abs(img_FFT_D3)))
xlim([1 length(img_FFT_D3)])
title("Dyadic, six Highest Frequency FFT (Mag)")

%   Modified pyramid case
%       3 highest-frequency = 0
figure
imagesc(img_MP1)
title("Modified Pyramid, Three Highest Frequency = 0")
colormap(gray)

imwrite(img_MP1,'img_MP_three_HF.bmp')

figure
plot(10*log10(abs(img_FFT_MP1)))
xlim([1 length(img_FFT_MP1)])
title("MP, three Highest Frequency FFT (Mag)")

%       10 highest-frequency = 0
figure
imagesc(img_MP2)
title("Modified Pyramid, Ten Highest Frequency = 0")
colormap(gray)
imwrite(img_MP2,'img_MP_ten_HF.bmp')

figure
plot(10*log10(abs(img_FFT_MP2)))
xlim([1 length(img_FFT_MP2)])
title("MP, ten Highest Frequency FFT (Mag)")

%       15 highest-frequency = 0
figure
imagesc(img_MP3)
title("Modified Pyramid, 15 Highest Frequency = 0")
colormap(gray)

imwrite(img_MP3,'img_MP_15_HF.bmp')

figure
plot(10*log10(abs(img_FFT_MP3)))
xlim([1 length(img_FFT_MP3)])
title("MP, 15 Highest Frequency FFT (Mag)")